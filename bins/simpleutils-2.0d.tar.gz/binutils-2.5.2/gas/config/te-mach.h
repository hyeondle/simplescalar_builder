#define TE_Mach
#include "obj-format.h"
