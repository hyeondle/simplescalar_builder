/* Intel 386 running LynxOS */

#ifndef hosts_i386lynx_h
#define hosts_i386lynx_h

#include "hosts/lynx.h"

#define	HOST_MACHINE_ARCH	bfd_arch_i386

#endif /* hosts_i386lynx_h */
