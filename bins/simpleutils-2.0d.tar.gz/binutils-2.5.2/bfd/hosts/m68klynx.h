/* Motorola 680x0 running LynxOS */

#ifndef hosts_m68klynx_H
#define hosts_m68klynx_H

#include "hosts/lynx.h"

#define	HOST_MACHINE_ARCH	bfd_arch_m68k

#endif /* hosts_m68klynx_H */
